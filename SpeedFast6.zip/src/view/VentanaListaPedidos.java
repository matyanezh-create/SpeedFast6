package view;

import controller.PedidoController;
import model.Pedido;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Ventana que muestra los pedidos en una JTable.
 * Permite actualizar la información mediante el botón Refrescar.
 */
public class VentanaListaPedidos extends JFrame {

    private DefaultTableModel model;

    public VentanaListaPedidos(PedidoController controller) {

        setTitle("Lista de Pedidos");
        setSize(550, 350);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        model = new DefaultTableModel();

        // Definición de columnas de la tabla
        model.addColumn("ID");
        model.addColumn("Dirección");
        model.addColumn("Tipo");
        model.addColumn("Repartidor");

        JTable tabla = new JTable(model);

        JButton btnRefrescar = new JButton("Refrescar");

        // Evento para actualizar la tabla
        btnRefrescar.addActionListener(e -> cargarDatos(controller));

        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
        panel.add(btnRefrescar, BorderLayout.SOUTH);

        add(panel);

        cargarDatos(controller);

        setVisible(true);
    }

    /**
     * Carga los datos actuales del controlador en la tabla.
     */
    private void cargarDatos(PedidoController controller) {

        model.setRowCount(0);

        for (Pedido p : controller.getListaPedidos()) {
            model.addRow(new Object[]{
                    p.getId(),
                    p.getDireccion(),
                    p.getTipo(),
                    p.getRepartidor()
            });
        }
    }
}
