package view;

import controller.PedidoController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Ventana que permite asignar un repartidor a un pedido existente.
 */
public class VentanaAsignarRepartidor extends JFrame {

    public VentanaAsignarRepartidor(PedidoController controller) {

        setTitle("Asignar Repartidor");
        setSize(380, 220);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JTextField txtId = new JTextField();
        JTextField txtNombre = new JTextField();
        JButton btnAsignar = new JButton("Asignar");

        panel.add(new JLabel("ID Pedido:"));
        panel.add(txtId);
        panel.add(new JLabel("Nombre Repartidor:"));
        panel.add(txtNombre);
        panel.add(new JLabel(""));
        panel.add(btnAsignar);

        add(panel);

        btnAsignar.addActionListener(e -> {

            if (txtId.getText().trim().isEmpty() ||
                    txtNombre.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Debe completar todos los campos");
                return;
            }

            controller.asignarRepartidor(
                    txtId.getText().trim(),
                    txtNombre.getText().trim());

            JOptionPane.showMessageDialog(this,
                    "Repartidor asignado correctamente");

            dispose();
        });

        setVisible(true);
    }
}
