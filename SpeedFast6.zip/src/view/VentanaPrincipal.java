package view;

import controller.PedidoController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Ventana principal del sistema.
 * Permite navegar hacia las distintas funcionalidades.
 */
public class VentanaPrincipal extends JFrame {

    private PedidoController controller;

    public VentanaPrincipal() {

        // Se instancia el controlador compartido
        controller = new PedidoController();

        setTitle("SpeedFast - Gestión de Entregas");
        setSize(420, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("Sistema SpeedFast", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        JPanel panelBotones = new JPanel(new GridLayout(3, 1, 15, 15));

        JButton btnRegistrar = new JButton("Registrar Pedido");
        JButton btnListar = new JButton("Listar Pedidos");
        JButton btnAsignar = new JButton("Asignar Repartidor");

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnListar);
        panelBotones.add(btnAsignar);

        panelPrincipal.add(titulo, BorderLayout.NORTH);
        panelPrincipal.add(panelBotones, BorderLayout.CENTER);

        add(panelPrincipal);

        // Eventos de navegación
        btnRegistrar.addActionListener(e -> new VentanaRegistroPedido(controller));
        btnListar.addActionListener(e -> new VentanaListaPedidos(controller));
        btnAsignar.addActionListener(e -> new VentanaAsignarRepartidor(controller));

        setVisible(true);
    }
}
