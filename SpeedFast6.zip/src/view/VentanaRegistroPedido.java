package view;

import controller.PedidoController;
import model.Pedido;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Ventana que permite registrar nuevos pedidos.
 * Incluye validaciones antes de guardar en memoria.
 */
public class VentanaRegistroPedido extends JFrame {

    public VentanaRegistroPedido(PedidoController controller) {

        setTitle("Registrar Pedido");
        setSize(380, 260);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JTextField txtId = new JTextField();
        JTextField txtDireccion = new JTextField();
        JComboBox<String> comboTipo = new JComboBox<>(
                new String[]{"Comida", "Encomienda", "Express"});

        JButton btnGuardar = new JButton("Guardar");

        panel.add(new JLabel("ID:"));
        panel.add(txtId);
        panel.add(new JLabel("Dirección:"));
        panel.add(txtDireccion);
        panel.add(new JLabel("Tipo:"));
        panel.add(comboTipo);
        panel.add(new JLabel(""));
        panel.add(btnGuardar);

        add(panel);

        // Acción del botón Guardar
        btnGuardar.addActionListener(e -> {

            String id = txtId.getText().trim();
            String direccion = txtDireccion.getText().trim();

            // Validación de campos vacíos
            if (id.isEmpty() || direccion.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Todos los campos son obligatorios");
                return;
            }

            // Validación de ID numérico
            if (!id.matches("\\d+")) {
                JOptionPane.showMessageDialog(this,
                        "El ID debe ser numérico");
                return;
            }

            // Validación de ID duplicado
            if (controller.existePedido(id)) {
                JOptionPane.showMessageDialog(this,
                        "Ya existe un pedido con ese ID");
                return;
            }

            // Creación del objeto Pedido
            Pedido p = new Pedido(id, direccion,
                    comboTipo.getSelectedItem().toString());

            // Guardado en memoria
            controller.agregarPedido(p);

            JOptionPane.showMessageDialog(this,
                    "Pedido registrado correctamente");

            dispose();
        });

        setVisible(true);
    }
}
