package main;

import view.VentanaPrincipal;

/**
 * Clase principal que inicia la aplicación SpeedFast.
 */
public class Main {

    public static void main(String[] args) {

        // Se instancia la ventana principal del sistema
        new VentanaPrincipal();
    }
}
