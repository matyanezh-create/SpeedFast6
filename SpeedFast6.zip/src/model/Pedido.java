package model;

/**
 * Clase que representa un Pedido dentro del sistema SpeedFast.
 * Contiene la información básica necesaria para gestionar una entrega.
 */
public class Pedido {

    // Identificador único del pedido
    private String id;

    // Dirección de entrega
    private String direccion;

    // Tipo de envío (Comida, Encomienda, Express)
    private String tipo;

    // Nombre del repartidor asignado
    private String repartidor;

    /**
     * Constructor que inicializa el pedido.
     * Por defecto el repartidor queda como "Sin asignar".
     */
    public Pedido(String id, String direccion, String tipo) {
        this.id = id;
        this.direccion = direccion;
        this.tipo = tipo;
        this.repartidor = "Sin asignar";
    }

    // Métodos getters
    public String getId() { return id; }
    public String getDireccion() { return direccion; }
    public String getTipo() { return tipo; }
    public String getRepartidor() { return repartidor; }

    /**
     * Permite asignar un repartidor al pedido.
     */
    public void setRepartidor(String repartidor) {
        this.repartidor = repartidor;
    }
}
