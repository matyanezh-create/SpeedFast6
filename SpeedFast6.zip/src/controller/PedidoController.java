package controller;

import model.Pedido;
import java.util.ArrayList;
import java.util.List;

/**
 * Controlador encargado de administrar los pedidos en memoria.
 * Actúa como intermediario entre la vista y el modelo.
 */
public class PedidoController {

    // Lista en memoria que almacena los pedidos registrados
    private List<Pedido> listaPedidos;

    public PedidoController() {
        listaPedidos = new ArrayList<>();
    }

    /**
     * Agrega un nuevo pedido a la lista.
     */
    public void agregarPedido(Pedido p) {
        listaPedidos.add(p);
    }

    /**
     * Devuelve la lista completa de pedidos.
     */
    public List<Pedido> getListaPedidos() {
        return listaPedidos;
    }

    /**
     * Verifica si ya existe un pedido con el mismo ID.
     */
    public boolean existePedido(String id) {
        for (Pedido p : listaPedidos) {
            if (p.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Asigna un repartidor a un pedido según su ID.
     */
    public void asignarRepartidor(String id, String nombre) {
        for (Pedido p : listaPedidos) {
            if (p.getId().equals(id)) {
                p.setRepartidor(nombre);
                break;
            }
        }
    }
}
